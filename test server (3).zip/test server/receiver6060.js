const express = require('express');
const app = express();
const PORT = 8081;

// const FIXED_IMPORT_RESPONSE = { code: 0, message: 'ok', content: [{ referenceId: '2550235', message: 'تم بنجاح', errorNo: '0' }] };
const FIXED_IMPORT_RESPONSE2 = { code: 2000, message: 'nok', content: [{ referenceId: '2550235', message: 'لم ينجاح', errorNo: '0' }] };
const FIXED_IMPORT_RESPONSE = { code: 2000, message: 'nok', content: [{ referenceId: '2550235', message: 'لم ينجاح', errorNo: '0' }] };
//const FIXED_IMPORT_RESPONSE= {code: 0, message :'Success',content:[{referenceId:'2598510',message:'The operation accomplished successfully.',errorNo:'0',docNo:'17472',docSer:'2025000001000010010000117472',statusCode:'400'}]};


function pickImportResponse() {
  return Math.random() < 0.5 ? FIXED_IMPORT_RESPONSE : FIXED_IMPORT_RESPONSE2;
}

app.use(express.json({
  verify: (req, _res, buf) => { req.rawBody = buf?.toString('utf8') || ''; }
}));

app.use((req, res, next) => {
  const started = Date.now();
  const _json = res.json.bind(res);
  const _send = res.send.bind(res);
  res.json = (body) => { res.locals._body = body; return _json(body); };
  res.send = (body) => { res.locals._body = body; return _send(body); };

  console.log(`\n➡️  ${req.method} ${req.originalUrl}`);
  if (req.headers) console.log('   Headers:', req.headers);
  if (req.rawBody) console.log('   Raw body:', req.rawBody);
  if (req.body !== undefined) console.log('   Parsed body:', req.body);

  res.on('finish', () => {
    console.log(`⬅️  ${res.statusCode} ${req.method} ${req.originalUrl} (${Date.now() - started}ms)`);
    console.log('   Res body:', res.locals._body);
    console.log(JSON.stringify(req.body, null, 2));
  });
  next();
});

app.post('/api/Auth/login', (_req, res) => res.json({ token: 'HARDCODED_TEST_TOKEN_12345' }));
app.post('/api/GL/ImportJournal', (_req, res) => res.json(pickImportResponse()));
app.get('/healthz', (_req, res) => res.send('ok'));

app.listen(PORT, () => console.log(`Mock listening on ${PORT}`));
