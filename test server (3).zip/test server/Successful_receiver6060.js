const express = require('express');

const app = express();
const PORT = 8081;

const SUCCESS_IMPORT_RESPONSE = {
  code: 0,
  message: 'ok',
  content: [
    {
      referenceId: '2550235',
      message: 'The operation accomplished successfully.',
      errorNo: '0',
      docNo: '17472',
      docSer: '2025000001000010010000117472',
      statusCode: '200',
    },
  ],
};

app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf?.toString('utf8') || '';
  },
}));

app.use((req, res, next) => {
  const started = Date.now();
  const originalJson = res.json.bind(res);
  const originalSend = res.send.bind(res);

  res.json = (body) => {
    res.locals.responseBody = body;
    return originalJson(body);
  };

  res.send = (body) => {
    res.locals.responseBody = body;
    return originalSend(body);
  };

  console.log(`\n${req.method} ${req.originalUrl}`);
  console.log('Headers:', req.headers);
  if (req.rawBody) {
    console.log('Raw body:', req.rawBody);
  }
  if (req.body !== undefined) {
    console.log('Parsed body:', req.body);
  }

  res.on('finish', () => {
    console.log(`${res.statusCode} ${req.method} ${req.originalUrl} (${Date.now() - started}ms)`);
    console.log('Response body:', res.locals.responseBody);
  });

  next();
});

app.post('/api/Auth/login', (_req, res) => {
  res.json({ token: 'HARDCODED_TEST_TOKEN_12345' });
});

app.post('/api/GL/ImportJournal', (_req, res) => {
  res.json(SUCCESS_IMPORT_RESPONSE);
});

app.get('/healthz', (_req, res) => {
  res.send('ok');
});

app.listen(PORT, () => {
  console.log(`Successful mock listening on ${PORT}`);
});
