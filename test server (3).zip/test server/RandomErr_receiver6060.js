const express = require('express');

const app = express();
const PORT = 8081;

function buildImportFailureResponse(body) {
  const firstEntry = Array.isArray(body) ? body[0] ?? {} : body ?? {};
  const referenceId = String(firstEntry.docSerExternal ?? '2575695');
  const amountLocal = Number(firstEntry.amountLocal ?? 169.67);

  return {
    code: 2002,
    message: 'Some entities can not be inserted',
    content: [
      {
        referenceId,
        message: `Error When Updating Post In Vouchers ORA-20420: Error When Insert Doc. Into Posting Tables , ORA-20333: : مشكلة في الترحيل = 1 , 53698\rORA-20469: لم تكتمل عملية الترحيل =1 , 53698\r = -${amountLocal}\rORA-0000: normal, successful completion`,
        errorNo: '20079',
        docNo: '',
        docSer: '',
        statusCode: '20420',
      },
    ],
  };
}

app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf?.toString('utf8') || '';
  },
}));

app.use((req, res, next) => {
  const started = Date.now();
  const originalJson = res.json.bind(res);
  const originalSend = res.send.bind(res);

  res.json = (body) => {
    res.locals.responseBody = body;
    return originalJson(body);
  };

  res.send = (body) => {
    res.locals.responseBody = body;
    return originalSend(body);
  };

  console.log(`\n${req.method} ${req.originalUrl}`);
  console.log('Headers:', req.headers);
  if (req.rawBody) {
    console.log('Raw body:', req.rawBody);
  }
  if (req.body !== undefined) {
    console.log('Parsed body:', req.body);
  }

  res.on('finish', () => {
    console.log(`${res.statusCode} ${req.method} ${req.originalUrl} (${Date.now() - started}ms)`);
    console.log('Response body:', res.locals.responseBody);
  });

  next();
});

app.post('/api/Auth/login', (_req, res) => {
  res.json({ token: 'HARDCODED_TEST_TOKEN_12345' });
});

app.post('/api/GL/ImportJournal', (req, res) => {
  res.json(buildImportFailureResponse(req.body));
});

app.get('/healthz', (_req, res) => {
  res.send('ok');
});

app.listen(PORT, () => {
  console.log(`Random receiver listening on ${PORT}`);
});
